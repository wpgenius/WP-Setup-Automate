<?php
/**
 * No items found.
 *
 * @package Astra Portfolio
 * @since 1.0.6
 */

?>
<div class="astra-portfolio-not-found">
	<p>
		<?php esc_html_e( 'No items found.', 'astra-portfolio' ); ?><br/>
	</p>
</div>
