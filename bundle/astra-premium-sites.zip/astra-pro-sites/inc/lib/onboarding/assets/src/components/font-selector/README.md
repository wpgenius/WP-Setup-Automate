## How to use?

```js
<FontSelector
    selected='open-sans'
    options={{
        'karla': 'Karla',
        'merriweather': 'Merriweather',
        'open-sans': 'Open Sans',
        'roboto': 'Roboto',
        'lobster': 'Lobster',
        'pacifico': 'Pacifico',
        'gloria-hallelujah': 'Gloria Hallelujah',
    }}
    onSelect={(selectedFont) => {
        // Conde goes here..
    }}
/>
```